import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

FirebaseFirestore db= FirebaseFirestore.instance;
List<String> colAsis =[];
//Leer
Future<List>getAsignacion() async{
  List asignacion=[];
  //pedir todos los elementos de una coleción
  QuerySnapshot queryAsignacion = await db.collection('asignacion').get();
  for (var doc in queryAsignacion.docs){
    final Map<String, dynamic> data = doc.data() as Map<String,dynamic>;
    final asig = {
      "docente": data['docente'],
      "edificio": data['edificio'],
      "horario": data['horario'],
      "materia": data['materia'],
      "salon": data['salon'],
      "uid": doc.id,
    };
    asignacion.add(asig);
  }
  return asignacion;
}
//Guardar
Future<void>addAsignacion(String dcn,String edf, String hor, String mat, String sal) async{
  await db.collection("asignacion").add({
    "docente": dcn,
    "edificio": edf,
    "horario": hor,
    "materia": mat,
    "salon": sal
  });
}
//Actualizar
Future<void>updateAsignacion(String uid, String dcn,String edf, String hor, String mat, String sal) async{
  await db.collection("asignacion").doc(uid).set({
    "docente": dcn,
    "edificio": edf,
    "horario": hor,
    "materia": mat,
    "salon": sal
  });
}
//Eliminar
Future<void> deleteAsignacion(String uid) async{
  await db.collection("asignacion").doc(uid).delete();
}
//-------------------------------ASISTENCIA---------------------------------------------
void createCollection(String col, String rev) async {
  DateTime now = DateTime.now();
  Timestamp timestamp = Timestamp.fromDate(now);
  try {
    await db.collection(col).add({
      'fecha/hora': timestamp,
      'revisor': rev,
    });
    print('Colección creada exitosamente');
  } catch (e) {
    print('Error al crear la colección: $e');
  }
}
Future<List> getAsistencia(String dcn) async {
  List asistencia = [];
  String coleccion = 'asistencia_$dcn';
  // Obtener todos los elementos de una colección
  QuerySnapshot queryAsignacion = await db.collection(coleccion).get();
  for (var doc in queryAsignacion.docs) {
    final Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    // Formatear la fecha y hora
    Timestamp timestamp = data['fecha/hora'];
    String formattedDateTime = DateFormat('dd/MM/yyyy HH:mm:ss').format(timestamp.toDate());
    final asis = {
      "revisor": data['revisor'],
      "fecha/hora": formattedDateTime,
      "uid": doc.id,
    };
    asistencia.add(asis);
  }
  return asistencia;
}
Future<void>addAsistencia(String col,String rev) async{
  print("colección encontrada, se agregara asistencia a $col");
  DateTime now = DateTime.now();
  Timestamp timestamp = Timestamp.fromDate(now);
  await db.collection(col).add({
    "revisor": rev,
    "fecha/hora":timestamp
  });
  colAsis.add(col);
  CollectionReference asistenciasCollection =  db.collection('asistencias');
  for (String elemento in colAsis) {
    await asistenciasCollection.add({
      'coleccion': elemento,
    });
  }
}
//-------------------OTRAS CONSULTAS----------------------------------
Future<List<String>> obtenerColecciones() async {
  List<String> colAsis = [];

  QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection("asistencias").get();

  for (QueryDocumentSnapshot documentSnapshot in querySnapshot.docs) {
    Map<String, dynamic>? data = documentSnapshot.data() as Map<String, dynamic>?;
    if (data != null) {
      String coleccion = data['coleccion'] as String;
      colAsis.add(coleccion);
    }
  }

  return colAsis;
}
/*
void recorrerColecciones() {
  List<String> colAsis = obtenerColecciones() as List<String>;
  for (String coleccion in colAsis) {
    // Realiza la acción para cada nombre de colección
    print('Colección: $coleccion');
    // Agrega aquí el código que deseas ejecutar para cada colección
  }
}*/
Future<List<String>> recorrerColecciones(String revisor) async {
  List<String> results = [];
  List<String> colAsis2 = obtenerColecciones() as List<String>;
  for (String coleccion in colAsis2) {
    print('Colección: $coleccion');

    QuerySnapshot querySnapshot = await db
        .collection(coleccion)
        .where('revisor', isEqualTo: revisor)
        .get();

    for (QueryDocumentSnapshot documentSnapshot in querySnapshot.docs) {
      Map<String, dynamic>? data = documentSnapshot.data() as Map<String, dynamic>?;
      if (data != null) {
        print('Revisor: ${data['revisor']}');
        print('Fecha/Hora: ${data['fecha/hora']}');
        results.add(coleccion);
      }
    }
  }

  return results;
}



