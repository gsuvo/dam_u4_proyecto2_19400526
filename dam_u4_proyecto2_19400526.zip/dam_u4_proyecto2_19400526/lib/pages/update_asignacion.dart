import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto2_19400526/services/firebase_services.dart';

class update_asigacion extends StatefulWidget {
  const update_asigacion({Key? key}) : super(key: key);

  @override
  State<update_asigacion> createState() => _update_asigacionState();
}

class _update_asigacionState extends State<update_asigacion> {
    TextEditingController docenteCon = TextEditingController(text: "");
    TextEditingController edificioCon = TextEditingController(text: "");
    TextEditingController horarioCon = TextEditingController(text: "");
    TextEditingController materiaCon = TextEditingController(text: "");
    TextEditingController salonCon = TextEditingController(text: "");
    @override
    Widget build(BuildContext context) {
      final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
      docenteCon.text=arguments['docente'];
      edificioCon.text=arguments['edificio'];
      horarioCon.text =arguments['horario'];
      materiaCon.text=arguments['materia'];
      salonCon.text=arguments['salon'];
      return Scaffold(
        appBar: AppBar(
          title: const Text('Agregar Asignación'),
          //backgroundColor: Colors.black87,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: docenteCon,
                decoration: const InputDecoration(
                  labelText: 'Docente',
                ),
              ),
              TextField(
                controller: edificioCon,
                decoration: const InputDecoration(
                  labelText: 'Edificio',
                ),
              ),
              TextField(
                controller: horarioCon,
                decoration: const InputDecoration(
                  labelText: 'Horario',
                ),
              ),
              TextField(
                controller: materiaCon,
                decoration: const InputDecoration(
                  labelText: 'Materia',
                ),
              ),
              TextField(
                controller: salonCon,
                decoration: const InputDecoration(
                  labelText: 'Salón',
                ),
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: () async {
                 await updateAsignacion(arguments['uid'],docenteCon.text,edificioCon.text,horarioCon.text,materiaCon.text,salonCon.text).then((_) {
                    Navigator.pop(context);
                  });
                },
                child: const Text('Actualizar'),
              ),
            ],
          ),
        ),
      );
    }
  }
