import 'dart:js_interop';
//import 'dart:math';
import 'package:dam_u4_proyecto2_19400526/services/firebase_services.dart';
import 'package:flutter/material.dart';

class Asistencia extends StatefulWidget {
  const Asistencia({Key? key}) : super(key: key);

  @override
  State<Asistencia> createState() => _AsistenciaState();

}

class _AsistenciaState extends State<Asistencia> {
  TextEditingController docenteCon = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    docenteCon.text=arguments['docente'];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrange,
        title: const Text('Asistencia'),
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepOrange,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/tec.png', // Ruta de la imagen
                    width: 64, // Ancho de la imagen
                    height: 64, // Alto de la imagen
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Asistencia de maestros',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            ListTile(
              title: const Text('Asignación'),
              onTap: () async {
                await Navigator.pushNamed(context, '/');
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('Consultas'),
              onTap: ()async {
                await Navigator.pushNamed(context, '/cons');
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      body: FutureBuilder(
          future: getAsistencia(arguments['docente']),
          builder: ((context, snapshot){
            if(snapshot.hasData) {

              if(getAsistencia(arguments['docente']).isNull){
                return AlertDialog(
                  title: Text('No se encontraron asistencias'),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('Aceptar'),
                    ),
                  ],
                );
              }else {
                return ListView.builder(
                  itemCount: snapshot.data?.length,
                  itemBuilder: (context, index) {
                    return Card(
                      margin: EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: EdgeInsets.all(20),
                            color: Colors.black87,
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    'Revisor: ${snapshot.data?[index]['revisor']}',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 5, width: 5),
                          Text(
                            'Fecha/Hora: ${snapshot.data?[index]['fecha/hora']}',
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    );
                  },
                );
              }
            }else{
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
          })),
      floatingActionButton: FloatingActionButton(
        onPressed: () async{
          await Navigator.pushNamed(context, '/');
          setState(() {

          });
        },
        child: const Icon(Icons.arrow_back),
      ),
    );
  }
  /*Color getRandomColor() {
    final Random random = Random();
    final int r = random.nextInt(256);
    final int g = random.nextInt(256);
    final int b = random.nextInt(256);
    return Color.fromRGBO(r, g, b, 100);
  }*/
}
