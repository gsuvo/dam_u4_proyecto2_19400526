import 'package:dam_u4_proyecto2_19400526/services/firebase_services.dart';
import 'package:flutter/material.dart';

class add_asignacion extends StatefulWidget {
  const add_asignacion({Key? key}) : super(key: key);

  @override
  State<add_asignacion> createState() => _add_asignacionState();
}

class _add_asignacionState extends State<add_asignacion> {
  TextEditingController docenteCon = TextEditingController(text: "");
  TextEditingController edificioCon = TextEditingController(text: "");
  TextEditingController horarioCon = TextEditingController(text: "");
  TextEditingController materiaCon = TextEditingController(text: "");
  TextEditingController salonCon = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Agregar Asignación'),
        //backgroundColor: Colors.black87,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: docenteCon,
              decoration: const InputDecoration(
                labelText: 'Docente',
              ),
            ),
            TextField(
              controller: edificioCon,
              decoration: const InputDecoration(
                labelText: 'Edificio',
              ),
            ),
            TextField(
              controller: horarioCon,
              decoration: const InputDecoration(
                labelText: 'Horario',
              ),
            ),
            TextField(
              controller: materiaCon,
              decoration: const InputDecoration(
                labelText: 'Materia',
              ),
            ),
            TextField(
              controller: salonCon,
              decoration: const InputDecoration(
                labelText: 'Salón',
              ),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () async {
                await addAsignacion(docenteCon.text,edificioCon.text,horarioCon.text,materiaCon.text,salonCon.text).then((_) {
                  Navigator.pop(context);
                });

              },
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
  }
}
