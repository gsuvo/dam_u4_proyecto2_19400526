//import 'dart:math';
import 'package:dam_u4_proyecto2_19400526/services/firebase_services.dart';
import 'package:flutter/material.dart';

class asignacion extends StatefulWidget {
  const asignacion({Key? key}) : super(key: key);

  @override
  State<asignacion> createState() => _asignacionState();
}

class _asignacionState extends State<asignacion> {
  @override
  Widget build(BuildContext context) {
    //final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    //revisorCon.text=arguments['revisor'];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrange,
        title: const Text('Asignación'),
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepOrange,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/tec.png', // Ruta de la imagen
                    width: 64, // Ancho de la imagen
                    height: 64, // Alto de la imagen
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Asistencia de maestros',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            ListTile(
              title: const Text('Asignación'),
              onTap: () async {
                await Navigator.pushNamed(context, '/');
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('Consultas'),
              onTap: () async {
                await Navigator.pushNamed(context, '/cons');
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      body: Column(
        children:[
           Row(
             mainAxisAlignment: MainAxisAlignment.center,
             children: [
               SizedBox(width: 8),
               Text(
                 'Para consultar o insertar asistencias presiona ',
                 style: TextStyle(
                   fontSize: 16,
                   fontWeight: FontWeight.w100,
                   color: Colors.grey
                 ),
               ),
               Icon(
                   Icons.access_time,
                   size: 24,
                   color: Colors.grey
               ),
             ],
           ),
          Expanded(
            child:  FutureBuilder(
              future: getAsignacion(),
              builder: ((context, snapshot){
                if(snapshot.hasData) {
                  return ListView.builder(
                    itemCount: snapshot.data?.length,
                    itemBuilder: (context, index) {
                        return Dismissible(
                          onDismissed: (direction)async{
                            await deleteAsignacion(snapshot.data?[index]['uid']);
                            snapshot.data?.removeAt(index);
                          },
                          confirmDismiss: (direction) async{
                            bool result =false;
                            result= await showDialog(
                                context: context,
                                builder: (context){
                                  return  AlertDialog(
                                    title:  Text("¿Deseas eliminar a ${snapshot.data?[index]['docente']}"),
                                      actions: [
                                        TextButton(onPressed: (){
                                              return Navigator.pop(
                                                  context,
                                                  false,
                                              );
                                        },
                                            child: const Text("Cancelar",style: TextStyle(color: Colors.red))),
                                        TextButton(onPressed: (){
                                          return Navigator.pop(
                                            context,
                                            true,
                                          );
                                        },
                                            child: const Text("Aceptar"))
                                      ],
                                  );
                            });return result;
                          },
                          key: Key(snapshot.data?[index]['uid']),
                          background: Container(
                            color: Colors.red,
                              child:const Icon(Icons.delete,color: Colors.white70)
                          ),
                          direction: DismissDirection.endToStart,
                          child: Card(
                            margin: EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(5),
                                    color:  Colors.black87,
                                    child: Row(
                                      children: [
                                        IconButton(
                                          icon: Icon(Icons.access_time_filled, color: Colors.white70),
                                          onPressed: () async {
                                            final String docente = snapshot.data?[index]['docente'];
                                            final String nuevaColeccion = 'asistencia_$docente';

                                            // Solicitar el valor del revisor mediante un AlertDialog
                                            final TextEditingController revisorController = TextEditingController();

                                            final String? revisor = await showDialog(
                                              context: context,
                                              builder: (BuildContext context) {
                                                return AlertDialog(
                                                  title: Text('Insertar asistencia'),
                                                  content: TextFormField(
                                                    controller: revisorController,
                                                    decoration: const InputDecoration(
                                                     labelText: 'Revisor',
                                                    ),
                                                  ),
                                                  actions: [
                                                    TextButton(
                                                      onPressed: () async{
                                                        await Navigator.pushNamed(context, "/asis",arguments: {
                                                          "docente": snapshot.data?[index]['docente'],
                                                        });
                                                      },
                                                      child: Text(
                                                        'Ver asistencias de ${snapshot.data?[index]['docente']}',
                                                        style: TextStyle(color: Colors.deepOrange),
                                                      ),
                                                    ),
                                                    TextButton(
                                                      onPressed: () {
                                                        // Obtener el valor del revisor
                                                        final String? revisor = revisorController.text;

                                                        if (revisor != null && revisor.isNotEmpty) {
                                                          // Se ingresó un valor de revisor
                                                          // Realizar las acciones necesarias aquí
                                                          if(getAsistencia(nuevaColeccion)==null){
                                                            createCollection(nuevaColeccion, revisor);
                                                            Navigator.pop(context, revisor);
                                                          }else{
                                                            addAsistencia(nuevaColeccion, revisorController.text);
                                                            Navigator.pop(context, revisor);
                                                          }
                                                        } else {
                                                          showDialog(
                                                            context: context,
                                                            builder: (BuildContext context) {
                                                              return AlertDialog(
                                                                title: Text('Por favor, ingrese el revisor'),
                                                                actions: [
                                                                  TextButton(
                                                                    onPressed: () {
                                                                      Navigator.pop(context);
                                                                    },
                                                                    child: Text('Aceptar'),
                                                                  ),
                                                                ],
                                                              );
                                                            },
                                                          );
                                                        }
                                                      },
                                                      child: Text('Aceptar'),
                                                    ),
                                                    TextButton(
                                                      onPressed: () {
                                                        Navigator.pop(context);
                                                      },
                                                      child: Text(
                                                        'Cancelar',
                                                        style: TextStyle(color: Colors.red),
                                                      ),
                                                    ),
                                                  ],
                                                );
                                              },
                                            );
                                            setState(() {});
                                          },
                                        ),
                                        Expanded(
                                          child: Text(
                                              snapshot.data?[index]['docente'],
                                              style: TextStyle(
                                                color: Colors.white
                                              ),
                                          ),

                                        ),
                                        IconButton(
                                          icon: Icon(Icons.edit, color: Colors.white70,),
                                          onPressed: () async {
                                            await Navigator.pushNamed(context, "/edit",arguments: {
                                            "docente": snapshot.data?[index]['docente'],
                                            "edificio": snapshot.data?[index]['edificio'],
                                            "horario": snapshot.data?[index]['horario'],
                                            "materia": snapshot.data?[index]['materia'],
                                            "salon": snapshot.data?[index]['salon'],
                                            "uid": snapshot.data?[index]['uid']
                                            });
                                            setState(() { });
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 5,width: 5),
                                  Text('edificio: ${snapshot.data?[index]['edificio']}',
                                  textAlign: TextAlign.center,),
                                  SizedBox(height: 5,width: 5),
                                  Text('horario: ${snapshot.data?[index]['horario']}',
                                      textAlign: TextAlign.center),
                                  SizedBox(height: 5,width: 5),
                                  Text('materia: ${snapshot.data?[index]['materia']}',
                                      textAlign: TextAlign.center),
                                  SizedBox(height: 5,width: 5),
                                  Text('salón: ${snapshot.data?[index]['salon']}',
                                      textAlign: TextAlign.center),
                                  SizedBox(height: 5,width: 5),
                            ],
                          ),
                        )
                      );
                  },
                );
                }else{
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              })),)
        ]
      ),
          floatingActionButton: FloatingActionButton(
            onPressed: () async{
              await Navigator.pushNamed(context, '/add');
              setState(() { });
            },
            child: const Icon(Icons.add),
          ),
    );
  }
 /* Color getRandomColor() {
    final Random random = Random();
    final int r = random.nextInt(256);
    final int g = random.nextInt(256);
    final int b = random.nextInt(256);
    return Color.fromRGBO(r, g, b, 100);
  }*/
}
