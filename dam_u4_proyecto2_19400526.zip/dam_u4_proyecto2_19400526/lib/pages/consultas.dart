import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto2_19400526/services/firebase_services.dart';
class consultas extends StatefulWidget {
  const consultas({Key? key}) : super(key: key);

  @override
  State<consultas> createState() => _consultasState();
}

class _consultasState extends State<consultas> {
  DateTime? fechaInicio;
  DateTime? fechaFin;
  String? edificio;
  String? revisor;

  TextEditingController revisorCon = TextEditingController(text: "");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Consultas'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Consultar asistencias de un rango de fechas para todos los maestros en todos los salones:'),
            ElevatedButton(
              onPressed: () {
                // Lógica para consultar asistencias por rango de fechas en todos los salones
                // Utiliza la fechaInicio y fechaFin para realizar la consulta
              },
              child: const Text('Consultar'),
            ),
            SizedBox(height: 16),
            Text('Consultar asistencia en rango de fechas POR EDIFICIO mostrando todos los maestros:'),
            DropdownButton<String>(
              value: edificio,
              onChanged: (value) {
                setState(() {
                  edificio = value;
                });
              },
              items: [
                DropdownMenuItem(
                  value: 'A',
                  child: Text('Edificio A'),
                ),
                DropdownMenuItem(
                  value: 'B',
                  child: Text('Edificio B'),
                ),
                DropdownMenuItem(
                  value: 'C',
                  child: Text('Edificio C'),
                ),
                DropdownMenuItem(
                  value: 'G',
                  child: Text('Edificio G'),
                ),
                DropdownMenuItem(
                  value: 'UD',
                  child: Text('Edificio UD'),
                ),
                DropdownMenuItem(
                  value: 'UVP',
                  child: Text('Edificio UVP'),
                ),
                DropdownMenuItem(
                  value: 'H',
                  child: Text('Edificio H'),
                )
              ],
            ),
            ElevatedButton(
              onPressed: () {
                if (edificio != null) {
                  // Lógica para consultar asistencia por rango de fechas y edificio
                  // Utiliza la fechaInicio, fechaFin y edificio para realizar la consulta
                } else {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: const Text('Error'),
                        content: const Text('Seleccione un edificio'),
                        actions: [
                          TextButton(
                            onPressed: () {

                              Navigator.pop(context);
                            },
                            child: const Text('Aceptar'),
                          ),
                        ],
                      );
                    },
                  );
                }
              },
              child: const Text('Consultar'),
            ),
            SizedBox(height: 16),
            Text('Consultar asistencia por revisor:'),
            TextFormField(
              onChanged: (value) {
                setState(() {
                  revisorCon.text = value;
                });
              },
              decoration: const InputDecoration(
                labelText: 'Revisor',
              ),
            ),
            ElevatedButton(
              onPressed: () {
                print(revisorCon.text);
                recorrerColecciones(revisorCon.text).then((List<String> results) {
                  showModalBottomSheet(
                    context: context,
                    builder: (BuildContext context) {
                      return ListView.builder(
                        itemCount: results.length,
                        itemBuilder: (context, index) {
                          final item = results[index];
                          return ListTile(
                            title: Text('Colección: $item'),
                          );
                        },
                      );
                    },
                  );
                });
              },
              child: const Text('Consultar'),
            ),
          ],
        ),
      ),
    );
  }
}
